/******************** */
/*     Lesson 1       */
/******************** */

/******************** */
/* Pre-class Workshop */
/******************** */

// export const message = "Hello moon!";
// export function sendMessage(msg) {
//   return msg;
// }

// export const sendMessage = (msg) => {
//     return msg;
// };
