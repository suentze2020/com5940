import os
import secrets
from PIL import Image
from flask import Flask, flash, render_template, request, redirect, url_for, session
# For pythonanywhere development, use the following code
# from flask_session import Session 
# and remove from flask_session.__init__ import Session
from flask_session.__init__ import Session 
from flask_bcrypt import Bcrypt
from functools import wraps
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.demo4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Association table for building many-to-many relationship between users table and blogs table.
user_blog = db.Table('users_blogs',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id')),
    db.Column('blog_id', db.Integer, db.ForeignKey('blogs.id'))
)
    
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    email = db.Column(db.String(255))
    password = db.Column(db.String(80))
    bio = db.Column(db.Text, nullable=False)
    admin = db.Column(db.Boolean)
    image_file = db.Column(db.String(255), nullable=False, default='default.jpg')
    active = db.Column(db.Boolean)
    following = db.relationship('Blog', secondary=user_blog, backref='followers')
    
class Blog(db.Model):
    __tablename__ = 'blogs'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255))
    body = db.Column(db.Text, nullable=False)
    author = db.Column(db.String(255))
    post_date = db.Column(db.TIMESTAMP, default=datetime.utcnow, nullable=False)
    views = db.Column(db.Integer,default=0)
    comments = db.Column(db.Integer,default=0)
    meta_desc = db.Column(db.Text)
    meta_keywords = db.Column(db.Text)
    lat = db.Column(db.Float)
    lng = db.Column(db.Float)
    url = db.Column(db.Text)
    img_url = db.Column(db.Text)
    
class Comment(db.Model):
    __tablename__ = 'comments'
    id = db.Column(db.Integer, primary_key=True)
    desc = db.Column(db.String(255))
    message = db.Column(db.Text)
